import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Contador from './Contador'
import ListaUsuarios from './ListaUsuarios';

function App() {

  const usuarios = [
    {nombre: 'Jhon Smith', edad: 39, profesion: 'Mecanico'},
    {nombre: 'Andrea Salvatti', edad: 19, profesion: 'Enfermera'},
    {nombre: 'Keny Doll', edad: 53, profesion: 'Bartender'},
  ];


  return (
    <> 
    <div className='box'>
      <h1>Estados y Props </h1>
      <Contador id="Contador"/>
    </div>
    <div className='box'>
      <h1>Lista de Usuarios</h1>
      <ListaUsuarios usuarios={usuarios} />
    </div>
    </>
  )
}

export default App
